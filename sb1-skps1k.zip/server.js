import express from 'express';
import fetch from 'node-fetch';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
const port = process.env.PORT || 3001;

app.use(express.json());

app.get('/api/check-trust', async (req, res) => {
  const { username } = req.query;
  
  if (!username) {
    return res.status(400).json({ error: 'ユーザー名が必要です。' });
  }

  try {
    const difyResponse = await fetch(`${process.env.DIFY_API_URL}/check-trust`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${process.env.DIFY_API_KEY}`
      },
      body: JSON.stringify({ username })
    });

    if (!difyResponse.ok) {
      const errorData = await difyResponse.json();
      throw new Error(errorData.error || 'Dify APIリクエストに失敗しました。');
    }

    const data = await difyResponse.json();
    res.json({ trustScore: data.trustScore });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ error: error.message || '信頼性の確認中にエラーが発生しました。' });
  }
});

app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});