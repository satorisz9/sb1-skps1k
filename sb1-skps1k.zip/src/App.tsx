import React, { useState } from 'react';
import { Search, AlertCircle } from 'lucide-react';

function App() {
  const [username, setUsername] = useState('');
  const [trustScore, setTrustScore] = useState<number | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const checkTrust = async () => {
    if (!username) {
      setError('ユーザー名を入力してください。');
      return;
    }

    setLoading(true);
    setError('');
    setTrustScore(null);

    try {
      const response = await fetch(`/api/check-trust?username=${encodeURIComponent(username)}`);
      if (!response.ok) {
        throw new Error('APIリクエストに失敗しました。');
      }
      const data = await response.json();
      setTrustScore(data.trustScore);
    } catch (err) {
      setError('信頼性の確認中にエラーが発生しました。');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center p-4">
      <div className="bg-white p-8 rounded-lg shadow-md w-full max-w-md">
        <h1 className="text-2xl font-bold mb-6 text-center text-gray-800">X アカウント信頼性チェッカー</h1>
        <div className="mb-4">
          <label htmlFor="username" className="block text-sm font-medium text-gray-700 mb-2">
            Xのユーザー名
          </label>
          <div className="relative">
            <input
              type="text"
              id="username"
              className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
              placeholder="@username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
            />
            <Search className="absolute right-3 top-2.5 text-gray-400" size={20} />
          </div>
        </div>
        <button
          onClick={checkTrust}
          disabled={loading}
          className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50 transition duration-200 ease-in-out disabled:opacity-50"
        >
          {loading ? '確認中...' : '信頼性を確認'}
        </button>
        {error && (
          <div className="mt-4 p-3 bg-red-100 border border-red-400 text-red-700 rounded-md flex items-center">
            <AlertCircle className="mr-2" size={20} />
            <span>{error}</span>
          </div>
        )}
        {trustScore !== null && (
          <div className="mt-6">
            <h2 className="text-lg font-semibold mb-2">信頼性スコア:</h2>
            <div className="bg-gray-200 rounded-full h-4 overflow-hidden">
              <div
                className="h-full bg-green-500"
                style={{ width: `${trustScore}%` }}
              ></div>
            </div>
            <p className="mt-2 text-center font-medium">
              {trustScore}% 信頼できる
            </p>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;